class DriverTypeError(Exception):
    pass
