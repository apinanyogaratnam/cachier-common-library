from cachier_common_library.DriverType import DriverType


class DriverType(DriverType):
    pass
