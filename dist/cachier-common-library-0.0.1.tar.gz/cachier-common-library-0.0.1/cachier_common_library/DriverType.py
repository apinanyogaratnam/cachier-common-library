class DriverType:
    RAM = 'ram'
    JSON = 'json'
    SQLITE = 'sqlite'
    PICKLE = 'pickle'
