from DriverType import DriverType


class DriverType(DriverType):
    pass
